# CHANGELOG v3.0 — 相对v2的所有变更

> **用途**：工程师对照此文件，知道哪些改、哪些不动、哪些删  
> **原则**：在现有代码基础上改造，不从零开始

---

## 🔴 删除（直接删，不保留）

| 内容 | 位置 | 原因 |
|---|---|---|
| Phaser Canvas渲染 | `client/src/ui/game/` | 改用Ink CLI渲染 |
| React HUD组件 | `client/src/ui/components/` | 同上 |
| 玩家操作按钮 | UI层 | 游戏100%由AI自主，无人工操作 |
| Zustand store | `client/src/ui/stores/` | 改用简单EventEmitter |
| phaser依赖 | `client/package.json` | 删除 |
| react-dom依赖 | `client/package.json` | 删除（Ink内置） |
| vite依赖 | `client/package.json` | 删除 |
| 03_Local_Game_UI.md | `prd&spec/` | 替换为 03_Client_CLI_Spec.md |

---

## 🟡 修改（在现有文件基础上改）

| 文件 | 改动 | 详见 |
|---|---|---|
| `client/bin/agentworld-mcp.js` | 同时启动Ink UI + MCP Server | 03_Client_CLI_Spec.md §2 |
| `client/src/mcp/server.js` | 新增 `aw_vip_intervene` 工具；`aw_start_session` 返回 `vip_available` 字段；`aw_get_score` 返回 `leaderboard_type` | 08_Leaderboard_VIP_Spec.md §3.2 |
| `client/package.json` | 删除旧依赖，新增 `ink`, `react`, `@inkjs/ui` | 03_Client_CLI_Spec.md §1.1 |
| `api/models/models.py` | `Score`表新增4字段；`ActionLog`表新增3字段；`Session`表新增2字段 | 08_Leaderboard_VIP_Spec.md §1 |
| `api/routers/sessions.py` | 新增VIP干涉处理逻辑；从LLM响应读取token数而非客户端上报 | 07_Security_AntiCheat_Spec.md §3 |
| `api/routers/leaderboard.py` | 支持 `type` 参数（pure_ai/vip）；返回 `model_distribution` 字段 | 08_Leaderboard_VIP_Spec.md §2.2 |
| `api/services/score_engine.py` | `total_tokens` 改从 `action_logs` 表读取，不信任客户端上报 | 07_Security_AntiCheat_Spec.md §3 |
| `api/services/npc_service.py` | LLM调用后自动写入 `model_name`/`input_tokens`/`output_tokens` | 08_Leaderboard_VIP_Spec.md §4 |
| `api/services/cheat_detector.py` | `SUSPICIOUS_SPEED_MS` 从关卡配置读取，改为可配置 | 07_Security_AntiCheat_Spec.md §2 |
| `api/services/world_engine.py` | 下发场景时只包含当前可见信息（按节点解锁），不返回完整关卡JSON | 07_Security_AntiCheat_Spec.md §1.3 |
| `docker-compose.yml` | 新增 `audit-worker` service | 07_Security_AntiCheat_Spec.md §2 层3 |
| `prd&spec/04_World_Config_Schema.md` | `map.tiled_json` 字段废弃（CLI不用Tiled），改为字符地图格式 | 见下方 §地图格式变更 |

---

## 🟢 新增（全新文件/功能）

| 内容 | 位置 | 详见 |
|---|---|---|
| CLI UI整套实现 | `client/src/ui/` (重写) | 03_Client_CLI_Spec.md |
| 进程内状态管理 | `client/src/store/gameState.js` | 03_Client_CLI_Spec.md §3 |
| FOV计算工具 | `client/src/ui/utils/fov.js` | 03_Client_CLI_Spec.md §4.2 |
| AES加密工具 | `api/utils/worldCrypto.js` | 07_Security_AntiCheat_Spec.md §1 |
| Nginx配置 | `/etc/nginx/conf.d/agentworld.conf` | 07_Security_AntiCheat_Spec.md §5 |
| 本地复盘存储 | `~/.agentworld/replays/` | 08_Leaderboard_VIP_Spec.md §5 |
| 排行榜规格文档 | `prd&spec/08_Leaderboard_VIP_Spec.md` | — |
| 安全规格文档 | `prd&spec/07_Security_AntiCheat_Spec.md` | — |

---

## ✅ 不动（现有代码保留，无需修改）

| 文件 | 说明 |
|---|---|
| `client/src/mcp/log-chain.js` | HMAC链实现完整，保留 |
| `client/src/api/client.js` | HTTP客户端保留 |
| `api/main.py` | 应用入口不变 |
| `api/config.py` | 配置不变 |
| `api/routers/auth.py` | 注册/登录不变 |
| `api/routers/worlds.py` | 关卡列表接口保留（返回内容会因world_engine改动而变化） |
| `api/routers/gm.py` | GM管理接口不变 |
| `api/services/ws_broadcaster.py` | WebSocket广播不变 |
| `api/services/condition_evaluator.py` | 条件求值不变 |
| `api/migrations/` | 已有迁移不变，新增字段写新migration文件 |
| `api/scripts/create_gm.py` | 不变 |
| `docker-compose.yml` 现有services | postgres/redis/api/gm 不变，只追加audit-worker |
| `deploy.sh` / `setup_vps.sh` | 不变 |
| `prd&spec/01_GM_UI_Design.md` | GM后台不变 |
| `prd&spec/02_API_Reference.md` | 保留，在新接口实现后补充文档 |
| `prd&spec/05_Engineering_Runbook.md` | 保留 |
| `prd&spec/06_Score_And_Audit_Service.md` | 保留，审计Worker实现参照此文档 |

---

## 地图格式变更（04_World_Config_Schema.md 局部修改）

原 `map.tiled_json` 字段（Phaser Tiled格式）废弃，改为字符地图：

```json
// 原格式（废弃）
"map": {
  "tiled_json": { ... }  // ❌ 删除
}

// 新格式
"map": {
  "width": 40,
  "height": 20,
  "tiles": [              // 二维字符数组
    "########################################",
    "#..............................#####...#",
    "#......@...............f.......#...#...#",
    ...
  ],
  "legend": {             // 可选，GM标注用
    "f": "陈福·酒馆老板",
    "%": "入场券"
  },
  "fov_radius": 8         // 可选，默认8
}
```

GM后台JSON编辑器（`gm-backend/`）相应调整输入格式，其余不变。

---

## 数据库迁移（新增，在现有migrations/基础上追加）

```bash
# 创建新迁移文件
docker compose exec api python -m alembic revision --autogenerate -m "v3_leaderboard_vip_model_tracking"

# 执行迁移
docker compose exec api python -m alembic upgrade head
```

新迁移文件将自动检测 models.py 变更并生成对应SQL。
