'use strict';
const readline = require('readline');
const { APIClient } = require('../api/client');
const { LogChain } = require('./log-chain');

/**
 * MCP Server for AgentWorld v3.
 * Exposes tools: aw_list_worlds, aw_start_session, aw_action, aw_end_session, aw_get_score, aw_vip_intervene
 */
class MCPServer {
  constructor() {
    this.baseUrl = process.env.AGENTWORLD_API_URL || 'http://localhost:9000';
    this.token = process.env.AGENTWORLD_TOKEN || '';
    this.api = new APIClient(this.baseUrl, this.token);

    this.session = null;
    this.chain = null;

    this.tools = {
      aw_list_worlds:    this._listWorlds.bind(this),
      aw_start_session:  this._startSession.bind(this),
      aw_action:         this._action.bind(this),
      aw_end_session:    this._endSession.bind(this),
      aw_get_score:      this._getScore.bind(this),
      aw_vip_intervene:  this._vipIntervene.bind(this),
    };
  }

  async start() {
    const rl = readline.createInterface({ input: process.stdin, terminal: false });

    process.stdout.write(JSON.stringify({
      jsonrpc: '2.0', method: 'notifications/initialized', params: {}
    }) + '\n');

    rl.on('line', async (line) => {
      let msg;
      try { msg = JSON.parse(line); } catch { return; }

      if (msg.method === 'initialize') {
        this._send({ id: msg.id, result: { protocolVersion: '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: 'agentworld', version: '3.0.0' } } });
        return;
      }

      if (msg.method === 'tools/list') {
        this._send({ id: msg.id, result: { tools: this._toolDefs() } });
        return;
      }

      if (msg.method === 'tools/call') {
        const { name, arguments: args } = msg.params;
        const handler = this.tools[name];
        if (!handler) {
          this._send({ id: msg.id, error: { code: -32601, message: `Unknown tool: ${name}` } });
          return;
        }
        try {
          const result = await handler(args || {});
          this._send({ id: msg.id, result: { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] } });
        } catch (err) {
          this._send({ id: msg.id, error: { code: -32000, message: err.message } });
        }
        return;
      }
    });

    rl.on('close', () => process.exit(0));
  }

  _send(obj) {
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', ...obj }) + '\n');
  }

  _toolDefs() {
    const defs = [
      {
        name: 'aw_list_worlds',
        description: 'List available AgentWorld game levels',
        inputSchema: { type: 'object', properties: {}, required: [] },
      },
      {
        name: 'aw_start_session',
        description: 'Start a new game session for a world. Returns vip_available indicating if VIP intervention is available.',
        inputSchema: {
          type: 'object',
          properties: {
            world_id: { type: 'string', description: 'World ID from aw_list_worlds' },
            model_id: { type: 'string', description: 'Claude model ID being used' },
          },
          required: ['world_id', 'model_id'],
        },
      },
      {
        name: 'aw_action',
        description: 'Perform a game action. Actions: observe, move, npc_talk, npc_action, use_item, memory_set, memory_get',
        inputSchema: {
          type: 'object',
          properties: {
            action: { type: 'string', enum: ['observe', 'move', 'npc_talk', 'npc_action', 'use_item', 'memory_set', 'memory_get'] },
            payload: { type: 'object', description: 'Action-specific payload' },
            reasoning: { type: 'string', description: 'Brief reasoning for this action' },
            token_cost: { type: 'number', description: 'Estimated tokens used for this step' },
          },
          required: ['action'],
        },
      },
      {
        name: 'aw_end_session',
        description: 'End the current game session',
        inputSchema: {
          type: 'object',
          properties: {
            end_reason: { type: 'string', enum: ['victory', 'defeat', 'timeout', 'abort'] },
          },
          required: ['end_reason'],
        },
      },
      {
        name: 'aw_get_score',
        description: 'Get the score for the current or last session. Returns leaderboard_type (pure_ai or vip).',
        inputSchema: { type: 'object', properties: {}, required: [] },
      },
      {
        name: 'aw_vip_intervene',
        description: '（仅VIP）向当前游戏注入一条额外上下文，本局将进入VIP排行榜。每关只能使用1次。',
        inputSchema: {
          type: 'object',
          properties: {
            content: { type: 'string', description: '注入的上下文内容（不得包含明确攻略）', maxLength: 500 },
          },
          required: ['content'],
        },
      },
    ];
    return defs;
  }

  async _listWorlds() {
    return this.api.get('/v1/worlds');
  }

  async _startSession({ world_id, model_id }) {
    if (this.session) {
      return { error: 'Session already active. End it first with aw_end_session.' };
    }
    const data = await this.api.post('/v1/session/start', {
      world_id,
      model_id,
      client_version: '3.0.0',
    });
    if (!data.ok) return data;

    this.session = data.data;
    this.chain = new LogChain(data.data.session_id, data.data.session_secret);

    // 更新进程内状态
    this._updateGameState({
      sessionId: data.data.session_id,
      worldName: data.data.initial_state?.world?.name || '',
      turn: 0,
      status: 'active',
      vipAvailable: data.data.vip_available || false,
      agent: {
        hp: data.data.initial_state?.player?.hp ?? 100,
        gold: data.data.initial_state?.player?.gold ?? 200,
        inventory: data.data.initial_state?.player?.inventory ?? [],
      },
    });
    this._addLog('system', `游戏开始：${data.data.initial_state?.world?.name || world_id}`, 0);

    return {
      session_id: data.data.session_id,
      initial_state: data.data.initial_state,
      turn: data.data.turn,
      vip_available: data.data.vip_available,
    };
  }

  async _action({ action, payload = {}, reasoning = '', token_cost = 0 }) {
    if (!this.session) return { error: 'No active session. Call aw_start_session first.' };

    const turn = (this.session.turn || 0) + 1;
    const entry = this.chain.addEntry({
      turn,
      action,
      payload,
      responseSummary: '',
      agentReasoningSummary: reasoning,
      tokenCost: token_cost,
    });

    this._addLog('think', `AI执行: ${action}`, turn);

    const data = await this.api.post('/v1/session/action', {
      session_id: this.session.session_id,
      turn,
      action,
      payload,
      ts_ns: entry.ts_ns,
      prev_hash: entry.prev_hash,
      entry_hash: entry.entry_hash,
    });

    if (data.ok) {
      this.session.turn = turn;
      this._updateGameState({ turn });

      const result = data.data?.result || {};
      // 更新 NPC 状态
      if (result.npc_response) {
        this._addLog('npc', result.npc_response, turn);
        this._updateGameState({
          currentNpc: result.npc_id ? {
            name: result.npc_name || result.npc_id,
            emotion: null,
            affinity: null,
          } : null,
        });
      }
      // 更新地图/位置
      if (result.position) {
        this._updateGameState({ playerPos: result.position });
      }
    }

    return data;
  }

  async _endSession({ end_reason }) {
    if (!this.session) return { error: 'No active session.' };

    const log = this.chain.exportLog();
    const data = await this.api.post('/v1/session/end', {
      session_id: this.session.session_id,
      end_reason,
      final_turn: this.session.turn || 0,
      chain_root_hash: log.chain_root_hash,
    });

    // Upload log for audit
    await this.api.post('/v1/session/upload-log', {
      session_id: this.session.session_id,
      log,
    }).catch(() => {});

    // 保存复盘
    if (end_reason !== 'victory') {
      this._saveReplay(end_reason);
    }

    this._addLog('system', `游戏结束：${end_reason}`, this.session.turn);
    this._updateGameState({ status: 'ended' });

    const sessionId = this.session.session_id;
    this.session = null;
    this.chain = null;

    return { ...data, session_id: sessionId };
  }

  async _getScore() {
    const id = this.session?.session_id;
    if (!id) return { error: 'No session.' };
    const data = await this.api.get(`/v1/session/${id}/score`);
    if (data.ok && data.data?.score) {
      this._updateGameState({ score: data.data.score });
    }
    return data;
  }

  async _vipIntervene({ content }) {
    if (!this.session) return { error: 'No active session.' };

    const data = await this.api.post('/v1/session/action', {
      session_id: this.session.session_id,
      turn: (this.session.turn || 0) + 1,
      action: 'vip_intervene',
      payload: { content },
      ts_ns: String(Date.now() * 1e6),
      prev_hash: '',
      entry_hash: '',
    });

    if (data.ok) {
      this._updateGameState({ vipAvailable: false, vipInterventionUsed: true, leaderboardType: 'vip' });
      this._addLog('system', 'VIP干涉已注入，本局进入VIP排行榜', this.session.turn);
    }

    return data;
  }

  // ---- 进程内状态更新 ----

  _updateGameState(patch) {
    try {
      const gameState = require('../store/gameState');
      gameState.update(patch);
    } catch (_) {}
  }

  _addLog(type, text, turn) {
    try {
      const gameState = require('../store/gameState');
      gameState.addLog(type, text, turn);
    } catch (_) {}
  }

  _saveReplay(reason) {
    try {
      const gameState = require('../store/gameState');
      gameState.saveReplay(reason);
    } catch (_) {}
  }
}

module.exports = { MCPServer };
