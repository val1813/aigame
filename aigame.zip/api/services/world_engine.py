import json
import time
from typing import Any

from services.condition_evaluator import ConditionEvaluator


class WorldEngine:
    """
    Core game state machine. Loads state from Redis, executes player actions,
    updates NPC states, evaluates quest nodes, checks win/fail conditions.
    """

    def __init__(self, world_config: dict, redis, session_id: str):
        self.config = world_config
        self.redis = redis
        self.session_id = session_id
        self._state_key = f"session:{session_id}:state"

    async def load_state(self) -> dict:
        raw = await self.redis.hgetall(self._state_key)
        npc_states = json.loads(raw.get("npc_states", "{}"))
        quest_states = json.loads(raw.get("quest_states", "{}"))
        inventory = json.loads(raw.get("inventory", "[]"))
        unlocked_info = json.loads(raw.get("unlocked_info", "[]"))

        return {
            "player": {
                "hp": int(raw.get("player_hp", 100)),
                "gold": int(raw.get("player_gold", 200)),
                "zone": raw.get("player_zone", ""),
                "inventory": inventory,
                "unlocked_info": unlocked_info,
                "inspected": json.loads(raw.get("inspected", "[]")),
                "position": {
                    "x": int(raw.get("player_x", 0)),
                    "y": int(raw.get("player_y", 0)),
                },
            },
            "npcs": npc_states,
            "quests": quest_states,
            "session": {
                "turn": int(raw.get("current_turn", 0)),
                "elapsed_ms": int(raw.get("elapsed_ms", 0)),
            },
            "completed_critical_nodes": int(raw.get("completed_critical_nodes", 0)),
            "hidden_events_found": int(raw.get("hidden_events_found", 0)),
            "total_tokens": int(raw.get("total_tokens", 0)),
        }

    async def execute_action(self, action: str, payload: dict, game_state: dict) -> dict:
        handler = {
            "observe": self._handle_observe,
            "move": self._handle_move,
            "npc_talk": self._handle_npc_talk,
            "npc_action": self._handle_npc_action,
            "use_item": self._handle_use_item,
            "memory_set": self._handle_memory_set,
            "memory_get": self._handle_memory_get,
        }.get(action)

        if not handler:
            return {"error": "FORBIDDEN_ACTION", "message": f"Unknown action: {action}"}

        result = await handler(payload, game_state)

        # After action: check win/fail conditions
        if not result.get("error"):
            await self._check_conditions(game_state)

        return result

    async def _handle_observe(self, payload: dict, state: dict) -> dict:
        pos = state["player"]["position"]
        zone_id = self._get_zone_at(pos["x"], pos["y"])
        zone_name = self._zone_name(zone_id)

        visible_npcs = []
        for npc in self.config.get("npcs", []):
            npc_pos = npc.get("position", {})
            if abs(npc_pos.get("x", -99) - pos["x"]) <= 3 and abs(npc_pos.get("y", -99) - pos["y"]) <= 3:
                npc_state = state["npcs"].get(npc["id"], {})
                visible_npcs.append({
                    "id": npc["id"],
                    "name": npc["name"],
                    "position": npc_pos,
                    "state": npc_state.get("current_state", npc.get("initial_state", "idle")),
                    "interactable": npc_state.get("alive", npc.get("alive", True)),
                })

        description = self._zone_description(zone_id)

        # 按节点解锁过滤：只返回当前已解锁的节点信息，防止AI提前获知未解锁剧情
        visible_nodes = self._get_visible_nodes(state)

        return {
            "result": {
                "position": {**pos, "zone": zone_id},
                "zone_name": zone_name,
                "description": description,
                "visible_npcs": visible_npcs,
                "visible_items": self._get_visible_items(state),
                "visible_events": visible_nodes,
            },
            "world_delta": {},
            "ws_events": [{"event": "observe", "data": {"zone": zone_id}}],
        }

    def _get_visible_nodes(self, state: dict) -> list:
        """只返回满足 unlock_condition 的节点信息，防止AI提前获知未解锁剧情"""
        ev = ConditionEvaluator(state)
        visible = []
        for node in self.config.get("nodes", []):
            cond = node.get("unlock_condition")
            if cond is None or ev.evaluate(cond):
                visible.append({
                    "id": node["id"],
                    "scene_info": node.get("scene_info", ""),
                })
        return visible

    def _get_visible_items(self, state: dict) -> list:
        """返回当前区域内可见道具"""
        pos = state["player"]["position"]
        items = []
        for item in self.config.get("items", []):
            item_pos = item.get("position", {})
            if abs(item_pos.get("x", -99) - pos["x"]) <= 5 and abs(item_pos.get("y", -99) - pos["y"]) <= 5:
                if item.get("id") not in state["player"].get("inventory", []):
                    items.append({"id": item["id"], "name": item.get("name", item["id"])})
        return items

    async def _handle_move(self, payload: dict, state: dict) -> dict:
        target = payload.get("target", {})
        zone_id = payload.get("zone_id")

        if zone_id:
            zone = next((z for z in self.config.get("map", {}).get("zones", []) if z["id"] == zone_id), None)
            if not zone:
                return {"error": "LOCKED_ZONE", "message": "Zone not found"}
            cond = zone.get("access_condition")
            if cond:
                ev = ConditionEvaluator(state)
                if not ev.evaluate(cond):
                    return {"error": "LOCKED_ZONE", "message": zone.get("locked_message", "Zone locked")}
            bounds = zone.get("bounds", {})
            target = {"x": bounds.get("x", 0), "y": bounds.get("y", 0)}

        new_x = target.get("x", state["player"]["position"]["x"])
        new_y = target.get("y", state["player"]["position"]["y"])

        await self.redis.hset(self._state_key, mapping={"player_x": new_x, "player_y": new_y})
        if zone_id:
            await self.redis.hset(self._state_key, "player_zone", zone_id)

        return {
            "result": {"position": {"x": new_x, "y": new_y}},
            "world_delta": {},
            "ws_events": [{"event": "agent_moved", "data": {"to": {"x": new_x, "y": new_y}}}],
        }

    async def _handle_npc_talk(self, payload: dict, state: dict) -> dict:
        npc_id = payload.get("npc_id")
        message = payload.get("message", "")

        npc_cfg = next((n for n in self.config.get("npcs", []) if n["id"] == npc_id), None)
        if not npc_cfg:
            return {"error": "NPC_NOT_IN_RANGE", "message": "NPC not found"}

        npc_state = state["npcs"].get(npc_id, {
            "current_state": npc_cfg.get("initial_state", "idle"),
            "alive": npc_cfg.get("alive", True),
            "conversation_turns": 0,
        })

        if not npc_state.get("alive", True):
            return {"error": "NPC_DEAD", "message": "NPC is dead"}

        if npc_cfg.get("type") == "llm":
            # Boss NPC: use LLM
            from services.npc_service import BossNPCService
            boss_svc = BossNPCService()
            response_text = await boss_svc.get_response(npc_cfg, [], message, npc_state.get("emotion", "suspicious"))
            npc_state["conversation_turns"] = npc_state.get("conversation_turns", 0) + 1
        else:
            # Scripted NPC: state machine
            trigger = self._message_to_trigger(message, npc_cfg)
            from services.npc_service import NPCStateMachine
            fsm = NPCStateMachine(npc_cfg, npc_state)
            fsm_result = fsm.process_trigger(trigger, state)
            response_text = fsm_result.response
            npc_state = fsm.state

            # Apply side effects
            for effect in fsm_result.side_effects:
                await self._apply_effect(effect, state)

            # Unlock info
            for info_id in fsm_result.unlocked_info:
                unlocked = json.loads(await self.redis.hget(self._state_key, "unlocked_info") or "[]")
                if info_id not in unlocked:
                    unlocked.append(info_id)
                    await self.redis.hset(self._state_key, "unlocked_info", json.dumps(unlocked))

            # Quest event
            if fsm_result.quest_event:
                await self._complete_quest_node(fsm_result.quest_event, state)

        # Persist NPC state
        all_npc_states = json.loads(await self.redis.hget(self._state_key, "npc_states") or "{}")
        all_npc_states[npc_id] = npc_state
        await self.redis.hset(self._state_key, "npc_states", json.dumps(all_npc_states))

        return {
            "result": {
                "npc_id": npc_id,
                "npc_name": npc_cfg["name"],
                "npc_response": response_text,
                "npc_state": npc_state.get("current_state", "idle"),
            },
            "world_delta": {npc_id: npc_state},
            "ws_events": [{"event": "npc_talked", "data": {"npc_id": npc_id, "text": response_text}}],
        }

    async def _handle_npc_action(self, payload: dict, state: dict) -> dict:
        npc_id = payload.get("npc_id")
        action_type = payload.get("action_type")
        action_payload = payload.get("payload", {})

        npc_cfg = next((n for n in self.config.get("npcs", []) if n["id"] == npc_id), None)
        if not npc_cfg:
            return {"error": "NPC_NOT_IN_RANGE", "message": "NPC not found"}

        npc_state = state["npcs"].get(npc_id, {
            "current_state": npc_cfg.get("initial_state", "idle"),
            "alive": True,
        })

        trigger = f"agent_{action_type}"
        from services.npc_service import NPCStateMachine
        fsm = NPCStateMachine(npc_cfg, npc_state)
        fsm_result = fsm.process_trigger(trigger, state)

        for effect in fsm_result.side_effects:
            await self._apply_effect(effect, state)

        for info_id in fsm_result.unlocked_info:
            unlocked = json.loads(await self.redis.hget(self._state_key, "unlocked_info") or "[]")
            if info_id not in unlocked:
                unlocked.append(info_id)
                await self.redis.hset(self._state_key, "unlocked_info", json.dumps(unlocked))

        if fsm_result.quest_event:
            await self._complete_quest_node(fsm_result.quest_event, state)

        all_npc_states = json.loads(await self.redis.hget(self._state_key, "npc_states") or "{}")
        all_npc_states[npc_id] = fsm.state
        await self.redis.hset(self._state_key, "npc_states", json.dumps(all_npc_states))

        return {
            "result": {"npc_id": npc_id, "npc_response": fsm_result.response},
            "world_delta": {npc_id: fsm.state},
            "ws_events": [],
        }

    async def _handle_use_item(self, payload: dict, state: dict) -> dict:
        item_id = payload.get("item_id")
        if item_id not in state["player"]["inventory"]:
            return {"error": "ITEM_NOT_OWNED", "message": "Item not in inventory"}
        return {"result": {"item_id": item_id, "used": True}, "world_delta": {}, "ws_events": []}

    async def _handle_memory_set(self, payload: dict, state: dict) -> dict:
        key = payload.get("key", "")
        value = payload.get("value")
        await self.redis.hset(f"session:{self.session_id}:memory", key, json.dumps(value))
        return {"result": {"key": key, "set": True}, "world_delta": {}, "ws_events": []}

    async def _handle_memory_get(self, payload: dict, state: dict) -> dict:
        key = payload.get("key", "")
        raw = await self.redis.hget(f"session:{self.session_id}:memory", key)
        value = json.loads(raw) if raw else None
        return {"result": {"key": key, "value": value}, "world_delta": {}, "ws_events": []}

    async def _apply_effect(self, effect: dict, state: dict):
        if effect.get("type") == "deduct_gold":
            amount = effect.get("amount", 0)
            new_gold = max(0, state["player"]["gold"] - amount)
            await self.redis.hset(self._state_key, "player_gold", new_gold)
            state["player"]["gold"] = new_gold

    async def _complete_quest_node(self, node_id: str, state: dict):
        quest_states = json.loads(await self.redis.hget(self._state_key, "quest_states") or "{}")
        for quest_id, quest_cfg in self.config.get("quests", {}).items():
            if node_id in quest_cfg.get("nodes", {}):
                if quest_id not in quest_states:
                    quest_states[quest_id] = {"nodes": {}}
                quest_states[quest_id]["nodes"][node_id] = {"complete": True}
                node_cfg = quest_cfg["nodes"][node_id]
                if node_cfg.get("is_critical_path"):
                    count = int(await self.redis.hget(self._state_key, "completed_critical_nodes") or 0)
                    await self.redis.hset(self._state_key, "completed_critical_nodes", count + 1)
        await self.redis.hset(self._state_key, "quest_states", json.dumps(quest_states))

    async def _check_conditions(self, state: dict):
        ev = ConditionEvaluator(state)
        for cond in self.config.get("fail_conditions", []):
            if ev.evaluate(cond):
                await self.redis.hset(self._state_key, "status", "failed")
                return
        for cond in self.config.get("win_conditions", []):
            if ev.evaluate(cond):
                await self.redis.hset(self._state_key, "status", "won")
                return

    def _get_zone_at(self, x: int, y: int) -> str:
        for zone in self.config.get("map", {}).get("zones", []):
            b = zone.get("bounds", {})
            if b.get("x", 0) <= x < b.get("x", 0) + b.get("w", 0) and \
               b.get("y", 0) <= y < b.get("y", 0) + b.get("h", 0):
                return zone["id"]
        return "unknown"

    def _zone_name(self, zone_id: str) -> str:
        for zone in self.config.get("map", {}).get("zones", []):
            if zone["id"] == zone_id:
                return zone.get("name", zone_id)
        return zone_id

    def _zone_description(self, zone_id: str) -> str:
        return f"你位于 {self._zone_name(zone_id)}。"

    def _message_to_trigger(self, message: str, npc_cfg: dict) -> str:
        """Simple keyword-based trigger mapping. Extend per world config."""
        msg = message.lower()
        if any(w in msg for w in ["你好", "hello", "hi", "嗨"]):
            return "agent_greet"
        if any(w in msg for w in ["会馆", "地址", "在哪", "位置"]):
            return "agent_ask_guild"
        if any(w in msg for w in ["钱", "金币", "给你", "贿赂", "买"]):
            return "agent_bribe"
        return "agent_talk"
