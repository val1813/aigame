export const metadata = { title: 'AgentWorld GM' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh">
      <body style={{ margin: 0, fontFamily: 'monospace', background: '#0d0d0d', color: '#e0e0e0' }}>
        {children}
      </body>
    </html>
  )
}
