'use client'
import { useState, useEffect } from 'react'

const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:9000'

function getToken() {
  return typeof window !== 'undefined' ? localStorage.getItem('gm_token') || '' : ''
}

export default function WorldEditor({ params }: { params: { id: string } }) {
  const [world, setWorld] = useState<any>(null)
  const [configText, setConfigText] = useState('')
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    loadWorld()
  }, [])

  async function loadWorld() {
    const token = getToken()
    const r = await fetch(`${API}/gm/worlds`, { headers: { Authorization: `Bearer ${token}` } })
    const data = await r.json()
    if (data.ok) {
      const w = data.data.find((x: any) => x.id === params.id)
      if (w) {
        setWorld(w)
        setConfigText(JSON.stringify(w.config || {}, null, 2))
      }
    }
  }

  async function save() {
    setError('')
    let config: any
    try {
      config = JSON.parse(configText)
    } catch {
      setError('Invalid JSON')
      return
    }
    const token = getToken()
    const r = await fetch(`${API}/gm/worlds/${params.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ config }),
    })
    const data = await r.json()
    if (data.ok) { setSaved(true); setTimeout(() => setSaved(false), 2000) }
    else setError('Save failed')
  }

  async function publish() {
    const token = getToken()
    await fetch(`${API}/gm/worlds/${params.id}/publish`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    })
    alert('Published!')
  }

  return (
    <div style={{ padding: 32 }}>
      <a href="/" style={{ color: '#7fbfff' }}>← Back</a>
      <h2 style={{ color: '#7fff7f' }}>Edit World: {params.id}</h2>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <button onClick={save} style={btn}>Save Config</button>
        <button onClick={publish} style={{ ...btn, borderColor: '#ffbf7f', color: '#ffbf7f' }}>Publish</button>
        {saved && <span style={{ color: '#7fff7f' }}>Saved!</span>}
        {error && <span style={{ color: 'red' }}>{error}</span>}
      </div>
      <textarea
        value={configText}
        onChange={e => setConfigText(e.target.value)}
        style={{
          width: '100%', height: '70vh', background: '#111', color: '#e0e0e0',
          border: '1px solid #444', borderRadius: 4, padding: 16, fontFamily: 'monospace', fontSize: 13,
        }}
      />
    </div>
  )
}

const btn: React.CSSProperties = {
  background: '#1a4a1a', border: '1px solid #7fff7f', color: '#7fff7f',
  padding: '8px 16px', borderRadius: 4, cursor: 'pointer',
}
